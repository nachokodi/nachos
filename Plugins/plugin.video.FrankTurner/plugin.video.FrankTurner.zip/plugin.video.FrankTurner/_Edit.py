import xbmcaddon

MainBase = 'https://goo.gl/FIV8AO'
addon = xbmcaddon.Addon('plugin.video.FrankTurner')